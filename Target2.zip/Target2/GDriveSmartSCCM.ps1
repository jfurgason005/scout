﻿# Props to Ralph-Gordon Paul @ https://gist.github.com/RGPaul/f1a306097d46a69a09c25ca34b79a804
# Share Gdrive file with anyone with this link as viewer and copy link.
# I used https://sites.google.com/site/gdocs2direct/home to get the link below from that link, but that likely isn't necessary.
#
# https://drive.google.com/uc?export=download&id=1U8KBqMcU4yRtfPc_XFqSCY69vwXx--9h
# Copy ID to $GoogleFileID as string
# Set $FileDestination as location of the downloaded file

$GoogleFileId = '1U8KBqMcU4yRtfPc_XFqSCY69vwXx--9h'
$FileDestination = 'C:\Windows\Temp\_x12x25.zip'
$ExtractPath = 'C:\Windows\Temp\_x12x25'


if (Test-Path $FileDestination) 
{
  Remove-Item $FileDestination
}

if (Test-Path $ExtractPath) 
{
  Remove-Item $ExtractPath -Force -Recurse
}

# set protocol to tls version 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Download the Virus Warning into _tmp.txt
Invoke-WebRequest -Uri "https://drive.google.com/uc?export=download&id=$GoogleFileId" -OutFile "_tmp.txt" -SessionVariable googleDriveSession

# Get confirmation code from _tmp.txt
$searchString = Select-String -Path "_tmp.txt" -Pattern "confirm="
$searchString -match "confirm=(?<content>.*)&amp;id="
$confirmCode = $matches['content']

# Delete _tmp.txt
Remove-Item "_tmp.txt"

# Download the real file
Invoke-WebRequest -Uri "https://drive.google.com/uc?export=download&confirm=${confirmCode}&id=$GoogleFileId" -OutFile $FileDestination -WebSession $googleDriveSession

Expand-Archive -LiteralPath $FileDestination -DestinationPath $ExtractPath

# SCCM reinstall cmd based on the presense of Airwatch
C:\windows\temp\_x12x25\1012or1025.cmd
